package com.radhe.model;

public enum TrackingStatus {
    ACTIVE,
    INACTIVE
}
